export interface InformixConfig {
  directIO: boolean;
  filesystemBlockSize: number; // in bytes (e.g., 4096)
  cpuVps: number;
  chunkCount: number;
}

export interface IOStrategy {
  mode: 'KAIO' | 'AIO_VP';
  threadsUsed: number;
  reason: string;
  efficiency: 'high' | 'medium' | 'low';
}