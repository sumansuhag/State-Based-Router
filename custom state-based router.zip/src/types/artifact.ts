export interface ArtifactData {
  fileName: string;
  verifiedChecksum: string;
  expectedChecksum: string;
  algorithm: string;
  db2Version: string;
  levelId: string;
  tokens: {
    product: string;
    build: string;
    fixPack: string;
    installPath: string;
  };
  status: 'verified' | 'mismatch' | 'unknown';
  timestamp: Date;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'success' | 'warning' | 'error';
  message: string;
}