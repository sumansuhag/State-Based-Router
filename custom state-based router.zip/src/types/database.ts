export interface DatabaseConnection {
  id: string;
  name: string;
  host: string;
  port: number;
  database: string;
  username: string;
  driver: string;
  ssl: boolean;
}

export type ConnectionStatusType = 'idle' | 'connecting' | 'connected' | 'error';