import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Label } from "../components/ui/label";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Switch } from "../components/ui/switch"; // Assuming Switch is available or using a custom toggle
import { InformixConfig } from "../types/informix";
import { HardDrive, Cpu, Layers } from "lucide-react";

interface ConfigPanelProps {
  config: InformixConfig;
  onChange: (config: Partial<InformixConfig>) => void;
}

export function ConfigPanel({ config, onChange }: ConfigPanelProps) {
  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Layers className="w-5 h-5 text-cyan-500" />
          Configuration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* DIRECT_IO Toggle */}
        <div className="flex items-center justify-between p-4 bg-slate-950 rounded-lg border border-slate-800">
          <div className="space-y-1">
            <Label htmlFor="direct-io" className="text-base font-medium text-white">
              DIRECT_IO
            </Label>
            <p className="text-xs text-slate-500">Bypass OS buffer cache</p>
          </div>
          <button
            onClick={() => onChange({ directIO: !config.directIO })}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
              config.directIO ? 'bg-cyan-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                config.directIO ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        {/* Filesystem Block Size */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2 text-sm text-slate-300">
            <HardDrive className="w-4 h-4" />
            Filesystem Block Size
          </Label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { val: 2048, label: '2k' },
              { val: 4096, label: '4k' },
              { val: 8192, label: '8k' },
              { val: 16384, label: '16k' },
              { val: 32768, label: '32k' },
              { val: 65536, label: '64k' }
            ].map((size) => (
              <Button
                key={size.val}
                variant={config.filesystemBlockSize === size.val ? "default" : "outline"}
                size="sm"
                onClick={() => onChange({ filesystemBlockSize: size.val })}
                className={
                  config.filesystemBlockSize === size.val 
                    ? "bg-cyan-600 hover:bg-cyan-500 border-cyan-500" 
                    : "border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
                }
              >
                {size.label}
              </Button>
            ))}
          </div>
          <p className="text-xs text-slate-500">
            Size of the underlying filesystem blocks (NOT dbspace pagesize).
          </p>
        </div>

        {/* CPU VPs */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2 text-sm text-slate-300">
            <Cpu className="w-4 h-4" />
            CPU VPs (Virtual Processors)
          </Label>
          <div className="flex items-center gap-4">
            <Input
              type="number"
              min="1"
              max="64"
              value={config.cpuVps}
              onChange={(e) => onChange({ cpuVps: parseInt(e.target.value) || 1 })}
              className="bg-slate-950 border-slate-700 text-white font-mono"
            />
            <span className="text-xs text-slate-500">
              Determines KAIO thread count (1:1)
            </span>
          </div>
        </div>

        {/* Chunk Count */}
        <div className="space-y-2">
          <Label className="text-sm text-slate-300">Active Chunks</Label>
          <Input
            type="range"
            min="1"
            max="10"
            value={config.chunkCount}
            onChange={(e) => onChange({ chunkCount: parseInt(e.target.value) })}
            className="w-full accent-cyan-500"
          />
          <div className="flex justify-between text-xs text-slate-500">
            <span>1</span>
            <span className="text-cyan-400 font-mono">{config.chunkCount}</span>
            <span>10</span>
          </div>
        </div>

      </CardContent>
    </Card>
  );
}