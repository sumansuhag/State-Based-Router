import { useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { RadioGroup, RadioGroupItem } from "../components/ui/radio-group";
import { DatabaseConnection } from "../types/database";

interface ConnectionFormProps {
  onSubmit: (connection: DatabaseConnection) => void;
  onCancel: () => void;
}

export function ConnectionForm({ onSubmit, onCancel }: ConnectionFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    host: "",
    port: 50000,
    database: "",
    username: "",
    driver: "db2",
    ssl: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData as DatabaseConnection);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <h2 className="text-xl font-semibold mb-6 text-slate-900">Configure New Connection</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="name">Connection Name</Label>
            <Input
              id="name"
              placeholder="Production Db2"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="driver">Driver Type</Label>
            <RadioGroup
              value={formData.driver}
              onValueChange={(value) => setFormData({ ...formData, driver: value })}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="db2" id="db2" />
                <Label htmlFor="db2" className="font-normal">Db2 (JCC)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="db2z" id="db2z" />
                <Label htmlFor="db2z" className="font-normal">Db2 for z/OS</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="host">Host</Label>
            <Input
              id="host"
              placeholder="db2.example.com"
              value={formData.host}
              onChange={(e) => setFormData({ ...formData, host: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="port">Port</Label>
            <Input
              id="port"
              type="number"
              value={formData.port}
              onChange={(e) => setFormData({ ...formData, port: parseInt(e.target.value) })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="database">Database Name</Label>
            <Input
              id="database"
              placeholder="SAMPLE"
              value={formData.database}
              onChange={(e) => setFormData({ ...formData, database: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              placeholder="db2admin"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              required
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="ssl"
            checked={formData.ssl}
            onChange={(e) => setFormData({ ...formData, ssl: e.target.checked })}
            className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
          />
          <Label htmlFor="ssl" className="font-normal">Enable SSL/TLS</Label>
        </div>

        <div className="flex gap-3 pt-4">
          <Button type="submit" className="bg-emerald-500 hover:bg-emerald-600">
            Save Connection
          </Button>
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
}