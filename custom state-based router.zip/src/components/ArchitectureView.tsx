import { InformixConfig } from "../types/informix";
import { determineStrategy } from "../utils/kaioLogic";
import { Cpu, Zap, HardDrive, ArrowDown } from "lucide-react";

export function ArchitectureView({ config }: InformixConfig) {
  const strategy = determineStrategy(config);
  const isKAIO = strategy.mode === 'KAIO';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 h-full">
      <h3 className="text-lg font-semibold mb-6 text-slate-200">Architecture Visualization</h3>
      
      <div className="flex flex-col items-center gap-8">
        
        {/* Layer 1: CPU VPs */}
        <div className="w-full">
          <div className="text-xs text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
            <Cpu className="w-3 h-3" />
            CPU Virtual Processors
          </div>
          <div className="flex justify-center gap-3 flex-wrap">
            {Array.from({ length: config.cpuVps }).map((_, i) => (
              <div key={i} className="w-16 h-16 bg-slate-800 border border-slate-700 rounded-lg flex flex-col items-center justify-center relative group">
                <span className="text-xs text-slate-400 font-mono">VP</span>
                <span className="text-lg font-bold text-white">{i + 1}</span>
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-2 bg-slate-600" />
              </div>
            ))}
          </div>
        </div>

        {/* Connector Lines */}
        <div className="flex flex-col items-center gap-1 py-2">
          <ArrowDown className="w-5 h-5 text-slate-600" />
          <div className="text-xs text-slate-500 font-mono">
            {isKAIO ? "1:1 Mapping" : "No Mapping"}
          </div>
        </div>

        {/* Layer 2: KAIO Threads (Conditional) */}
        <div className={`w-full transition-all duration-500 ${isKAIO ? 'opacity-100' : 'opacity-30 grayscale'}`}>
          <div className="text-xs text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
            <Zap className={`w-3 h-3 ${isKAIO ? 'text-cyan-400' : ''}`} />
            KAIO Threads (Kernel)
          </div>
          <div className="flex justify-center gap-3 flex-wrap">
            {Array.from({ length: config.cpuVps }).map((_, i) => (
              <div key={i} className={`w-16 h-16 rounded-lg flex flex-col items-center justify-center border-2 ${
                isKAIO 
                  ? 'bg-cyan-950/30 border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.15)]' 
                  : 'bg-slate-800 border-slate-700'
              }`}>
                <span className="text-xs text-slate-400 font-mono">KAIO</span>
                <span className="text-lg font-bold text-cyan-400">{i + 1}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Connector Lines to Storage */}
        <div className="w-full h-px bg-slate-800 my-2 relative">
          <div className={`absolute top-1/2 left-0 w-full h-0.5 ${isKAIO ? 'bg-cyan-500/50' : 'bg-slate-700'}`} />
          {Array.from({ length: config.chunkCount }).map((_, i) => (
            <div 
              key={i} 
              className="absolute top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-slate-500"
              style={{ left: `${((i + 1) / (config.chunkCount + 1)) * 100}%` }}
            />
          ))}
        </div>

        {/* Layer 3: Chunks / Storage */}
        <div className="w-full">
          <div className="text-xs text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
            <HardDrive className="w-3 h-3" />
            Chunks on Filesystem
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {Array.from({ length: config.chunkCount }).map((_, i) => (
              <div key={i} className="p-3 bg-slate-950 border border-slate-700 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-mono text-slate-400">Chunk {i + 1}</span>
                  {isKAIO && <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />}
                </div>
                <div className="text-[10px] text-slate-500">
                  Block: {(config.filesystemBlockSize / 1024).toFixed(0)}k
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}