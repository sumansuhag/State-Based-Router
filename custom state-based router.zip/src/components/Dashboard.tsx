import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { ArtifactData } from "../types/artifact";
import { TerminalView } from "./TerminalView";
import { MetadataInspector } from "./MetadataInspector";
import { CheckCircle, Shield, Fingerprint, Activity, Cpu } from "lucide-react";

interface DashboardProps {
  artifact: ArtifactData | null;
  isScanning: boolean;
  onScan: () => void;
}

export function Dashboard({ artifact, isScanning, onScan }: DashboardProps) {
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    if (isScanning) {
      const interval = setInterval(() => setPulse(p => !p), 1000);
      return () => clearInterval(interval);
    }
  }, [isScanning]);

  return (
    <div className="max-w-7xl mx-auto p-6 lg:p-10">
      {/* Header */}
      <header className="mb-10 flex items-center justify-between border-b border-slate-800 pb-6">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-xl ${isScanning ? 'bg-emerald-500/20 animate-pulse' : 'bg-slate-800'}`}>
            <Shield className={`w-8 h-8 ${isScanning ? 'text-emerald-400' : 'text-slate-400'}`} />
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-white">Dependency Integrity Verifier</h1>
            <p className="text-slate-400 mt-1">Cryptographic checksum analysis for enterprise artifacts</p>
          </div>
        </div>
        <Button 
          onClick={onScan} 
          disabled={isScanning}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-mono px-6"
        >
          {isScanning ? (
            <>
              <Activity className="w-4 h-4 mr-2 animate-spin" />
              ANALYZING...
            </>
          ) : (
            <>
              <Fingerprint className="w-4 h-4 mr-2" />
              VERIFY ARTIFACT
            </>
          )}
        </Button>
      </header>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Status & Terminal */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Verification Status Card */}
          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Cpu className="w-5 h-5 text-emerald-500" />
                Analysis Result
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isScanning ? (
                <div className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <div className="w-16 h-16 border-4 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-slate-400 animate-pulse">Computing hash values...</p>
                  </div>
                </div>
              ) : artifact ? (
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-slate-950 rounded-lg border border-slate-800">
                    <div>
                      <div className="text-sm text-slate-400 mb-1">Status</div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-emerald-500" />
                        <span className="text-xl font-bold text-emerald-400">VERIFIED</span>
                      </div>
                    </div>
                    <Badge variant="outline" className="border-emerald-500/50 text-emerald-400">
                      {artifact.algorithm} MATCH
                    </Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-950 rounded-lg border border-slate-800">
                      <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Artifact Name</div>
                      <div className="font-mono text-lg text-white">{artifact.fileName}</div>
                    </div>
                    <div className="p-4 bg-slate-950 rounded-lg border border-slate-800">
                      <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Db2 Release</div>
                      <div className="font-mono text-lg text-white">{artifact.tokens.product}</div>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-950 rounded-lg border border-slate-800">
                    <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Checksum Comparison</div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-sm">
                      <div>
                        <div className="text-slate-500 mb-1">Calculated (Local)</div>
                        <div className="text-emerald-400 break-all">{artifact.verifiedChecksum}</div>
                      </div>
                      <div>
                        <div className="text-slate-500 mb-1">Expected (Remote)</div>
                        <div className="text-slate-300 break-all">{artifact.expectedChecksum}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500">
                  <Shield className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>Ready to analyze. Click "Verify Artifact" to begin.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Terminal Output */}
          <TerminalView />
        </div>

        {/* Right Column: Metadata */}
        <div className="space-y-6">
          {artifact && <MetadataInspector artifact={artifact} />}
          
          {/* Info Card */}
          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-base">Verification Context</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-slate-400 space-y-3">
              <p>
                This analysis confirms that the Maven-hosted artifact matches the binary 
                distributed within the official IBM Db2 12.1.3.0 container image.
              </p>
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <code className="text-xs text-slate-300">
                  Source: db2inst1@db2-12-1<br/>
                  Path: ~/sqllib/java/db2jcc4.jar
                </code>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}