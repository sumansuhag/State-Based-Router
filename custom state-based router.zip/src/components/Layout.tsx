import { ReactNode } from "react";
import { Navigation } from "./Navigation";
import { Page } from "../App"; // Assuming type is exported or inferred

interface LayoutProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  children: ReactNode;
}

export function Layout({ currentPage, onPageChange, children }: LayoutProps) {
  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-50 font-sans">
      {/* Sidebar Navigation */}
      <aside className="w-64 border-r border-slate-800 bg-slate-900/50 hidden md:flex flex-col">
        <div className="p-6 border-b border-slate-800">
          <h1 className="text-xl font-bold text-white tracking-tight">
            IDS <span className="text-cyan-400">IO-Sim</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">v1.0.4 (Kagel Logic)</p>
        </div>
        
        <div className="flex-1 p-4">
          <Navigation currentPage={currentPage} onSelect={onPageChange} />
        </div>

        <div className="p-4 border-t border-slate-800">
          <div className="text-xs text-slate-600">
            © {new Date().getFullYear()} ASK DB Corp<br/>
            Reference Implementation
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden p-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
          <span className="font-bold text-white">IDS IO-Sim</span>
          <Navigation currentPage={currentPage} onSelect={onPageChange} isMobile />
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 lg:p-10">
          {children}
        </div>
      </main>
    </div>
  );
}