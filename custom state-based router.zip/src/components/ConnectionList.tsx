import { DatabaseConnection } from "../types/database";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Trash, Play } from "lucide-react";

interface ConnectionListProps {
  connections: DatabaseConnection[];
  onConnect: (connection: DatabaseConnection) => void;
  onDelete: (id: string) => void;
  activeId: string | undefined;
}

export function ConnectionList({ connections, onConnect, onDelete, activeId }: ConnectionListProps) {
  if (connections.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-10 h-10 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" />
          </svg>
        </div>
        <h3 className="text-lg font-medium text-slate-900 mb-2">No connections configured</h3>
        <p className="text-slate-500 mb-6">Add your first Db2 database connection to get started</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {connections.map((connection) => (
        <Card key={connection.id} className={`border-2 transition-all ${
          activeId === connection.id ? 'border-emerald-500 shadow-md' : 'border-slate-200 hover:border-slate-300'
        }`}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-lg">{connection.name}</CardTitle>
                <CardDescription className="mt-1">
                  {connection.driver.toUpperCase()} • {connection.database}
                </CardDescription>
              </div>
              <button
                onClick={() => onDelete(connection.id)}
                className="text-slate-400 hover:text-red-500 transition-colors"
              >
                <Trash className="w-4 h-4" />
              </button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm text-slate-600 mb-4">
              <div className="flex justify-between">
                <span>Host:</span>
                <span className="font-mono">{connection.host}</span>
              </div>
              <div className="flex justify-between">
                <span>Port:</span>
                <span className="font-mono">{connection.port}</span>
              </div>
              <div className="flex justify-between">
                <span>User:</span>
                <span className="font-mono">{connection.username}</span>
              </div>
              <div className="flex justify-between">
                <span>SSL:</span>
                <span className={connection.ssl ? "text-emerald-600" : "text-slate-400"}>
                  {connection.ssl ? "Enabled" : "Disabled"}
                </span>
              </div>
            </div>
            <Button
              onClick={() => onConnect(connection)}
              className={`w-full ${
                activeId === connection.id
                  ? "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  : "bg-emerald-500 hover:bg-emerald-600 text-white"
              }`}
              disabled={activeId === connection.id}
            >
              {activeId === connection.id ? (
                "Connected"
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Connect
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}