import { ArtifactData } from "../types/artifact";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Hash, Package, HardDrive } from "lucide-react";

interface MetadataInspectorProps {
  artifact: ArtifactData;
}

export function MetadataInspector({ artifact }: MetadataInspectorProps) {
  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Package className="w-4 h-4 text-blue-400" />
          Metadata Inspector
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        
        {/* Version Info */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-500">Code Release</span>
            <span className="font-mono text-white">{artifact.db2Version}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-500">Level Identifier</span>
            <span className="font-mono text-white">{artifact.levelId}</span>
          </div>
        </div>

        <div className="h-px bg-slate-800"></div>

        {/* Informational Tokens */}
        <div className="space-y-3">
          <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Informational Tokens</div>
          
          <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="text-[10px] mt-0.5 h-5 px-1.5 border-slate-700 text-slate-400">PROD</Badge>
              <span className="text-sm text-slate-300 break-all">{artifact.tokens.product}</span>
            </div>
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="text-[10px] mt-0.5 h-5 px-1.5 border-slate-700 text-slate-400">BUILD</Badge>
              <span className="text-sm text-slate-300 font-mono">{artifact.tokens.build}</span>
            </div>
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="text-[10px] mt-0.5 h-5 px-1.5 border-slate-700 text-slate-400">FP</Badge>
              <span className="text-sm text-slate-300">{artifact.tokens.fixPack}</span>
            </div>
          </div>
        </div>

        <div className="h-px bg-slate-800"></div>

        {/* Install Path */}
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <HardDrive className="w-3 h-3" />
            INSTALLATION PATH
          </div>
          <div className="p-2 bg-slate-950 rounded border border-slate-800">
            <code className="text-xs text-blue-300 break-all">{artifact.tokens.installPath}</code>
          </div>
        </div>

      </CardContent>
    </Card>
  );
}