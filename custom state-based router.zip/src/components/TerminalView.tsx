import { useEffect, useState } from "react";
import { VerificationEngine } from "../utils/verificationEngine";
import { LogEntry } from "../types/artifact";
import { Terminal } from "lucide-react";

export function TerminalView() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      const currentLogs = VerificationEngine.getLogs();
      if (currentLogs.length !== logs.length) {
        setLogs(currentLogs);
        setIsVisible(true);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [logs]);

  const getLevelColor = (level: LogEntry['level']) => {
    switch(level) {
      case 'success': return 'text-emerald-400';
      case 'error': return 'text-red-400';
      case 'warning': return 'text-amber-400';
      default: return 'text-slate-400';
    }
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
      <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center gap-2">
        <Terminal className="w-4 h-4 text-slate-500" />
        <span className="text-sm font-medium text-slate-300">Verification Log</span>
        <div className="ml-auto flex gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50"></div>
          <div className="w-3 h-3 rounded-full bg-amber-500/20 border border-amber-500/50"></div>
          <div className="w-3 h-3 rounded-full bg-emerald-500/20 border border-emerald-500/50"></div>
        </div>
      </div>
      <div className="p-4 h-64 overflow-y-auto font-mono text-xs space-y-1">
        {logs.length === 0 ? (
          <div className="text-slate-600 italic">Waiting for analysis...</div>
        ) : (
          logs.map((log) => (
            <div key={log.id} className="flex gap-3">
              <span className="text-slate-600 select-none">
                [{new Date(log.timestamp).toLocaleTimeString('en-US', {hour12: false})}]
              </span>
              <span className={getLevelColor(log.level)}>
                {log.level.toUpperCase()}:
              </span>
              <span className="text-slate-300">{log.message}</span>
            </div>
          ))
        )}
        <div className="flex items-center gap-2 mt-2 text-slate-600">
          <span className="animate-pulse">▊</span>
        </div>
      </div>
    </div>
  );
}