import { DatabaseConnection } from "../types/database";
import { Button } from "../components/ui/button";
import { CheckCircle, XCircle } from "lucide-react";

interface ConnectionStatusProps {
  connection: DatabaseConnection;
  onDisconnect: () => void;
}

export function ConnectionStatus({ connection, onDisconnect }: ConnectionStatusProps) {
  return (
    <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center">
            <CheckCircle className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-emerald-900 text-lg">Connected to {connection.name}</h3>
            <p className="text-emerald-700 text-sm">
              {connection.host}:{connection.port} / {connection.database}
            </p>
          </div>
        </div>
        <Button
          onClick={onDisconnect}
          variant="outline"
          className="border-emerald-300 text-emerald-700 hover:bg-emerald-100"
        >
          Disconnect
        </Button>
      </div>
      
      <div className="mt-4 pt-4 border-t border-emerald-200">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <span className="text-emerald-600 block">Driver</span>
            <span className="font-medium text-emerald-900">{connection.driver.toUpperCase()}</span>
          </div>
          <div>
            <span className="text-emerald-600 block">Protocol</span>
            <span className="font-medium text-emerald-900">TCPIP</span>
          </div>
          <div>
            <span className="text-emerald-600 block">SSL</span>
            <span className="font-medium text-emerald-900">{connection.ssl ? "Yes" : "No"}</span>
          </div>
          <div>
            <span className="text-emerald-600 block">Latency</span>
            <span className="font-medium text-emerald-900">12ms</span>
          </div>
        </div>
      </div>
    </div>
  );
}