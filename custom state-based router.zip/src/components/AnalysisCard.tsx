import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { InformixConfig } from "../types/informix";
import { determineStrategy } from "../utils/kaioLogic";
import { Zap, AlertTriangle, CheckCircle, Info } from "lucide-react";

interface AnalysisCardProps {
  config: InformixConfig;
}

export function AnalysisCard({ config }: AnalysisCardProps) {
  const strategy = determineStrategy(config);

  const getStatusColor = () => {
    if (strategy.efficiency === 'high') return 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
    if (strategy.efficiency === 'medium') return 'text-amber-400 border-amber-500/30 bg-amber-500/10';
    return 'text-slate-400 border-slate-700 bg-slate-800';
  };

  const getIcon = () => {
    if (strategy.efficiency === 'high') return <CheckCircle className="w-5 h-5" />;
    if (strategy.efficiency === 'medium') return <AlertTriangle className="w-5 h-5" />;
    return <Info className="w-5 h-5" />;
  };

  return (
    <Card className={`border ${getStatusColor()}`}>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          {getIcon()}
          I/O Strategy Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-400">Mode</span>
          <Badge variant="outline" className={strategy.mode === 'KAIO' ? 'border-cyan-500 text-cyan-400' : 'border-slate-600 text-slate-400'}>
            {strategy.mode}
          </Badge>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-400">Threads</span>
          <span className="font-mono text-white">{strategy.threadsUsed}</span>
        </div>

        <div className="pt-3 border-t border-slate-700/50">
          <p className="text-xs leading-relaxed text-slate-300">
            {strategy.reason}
          </p>
        </div>

        {strategy.mode === 'KAIO' && (
          <div className="flex items-start gap-2 text-xs text-emerald-400 mt-2">
            <Zap className="w-3 h-3 mt-0.5" />
            <span>Optimal path: Kernel handles I/O directly.</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}