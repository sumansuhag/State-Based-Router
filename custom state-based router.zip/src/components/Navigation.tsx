import { Button } from "./ui/button";
import { LayoutDashboard, BookOpen, Settings } from "lucide-react";

interface NavigationProps {
  currentPage: string;
  onSelect: (page: string) => void;
  isMobile?: boolean;
}

const navItems = [
  { id: 'dashboard', label: 'Simulator', icon: LayoutDashboard },
  { id: 'docs', label: 'Documentation', icon: BookOpen },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function Navigation({ currentPage, onSelect, isMobile = false }: NavigationProps) {
  if (isMobile) {
    return (
      <div className="flex gap-2">
        {navItems.map((item) => (
          <Button
            key={item.id}
            variant={currentPage === item.id ? "default" : "ghost"}
            size="sm"
            onClick={() => onSelect(item.id)}
            className={currentPage === item.id ? "bg-cyan-600 text-white" : "text-slate-400"}
          >
            <item.icon className="w-4 h-4" />
          </Button>
        ))}
      </div>
    );
  }

  return (
    <nav className="space-y-1">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = currentPage === item.id;
        
        return (
          <button
            key={item.id}
            onClick={() => onSelect(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              isActive 
                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
            {item.label}
          </button>
        );
      })}
    </nav>
  );
}