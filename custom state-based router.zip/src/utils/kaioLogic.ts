import { InformixConfig, IOStrategy } from "../types/informix";

/**
 * Implements the logic described by Art S. Kagel:
 * 1. If DIRECT_IO is set -> All chunks handled by KAIO threads (1 per CPU VP).
 * 2. If Filesystem Block Size > 2k -> Handled by KAIO threads (in latest update).
 * 3. Otherwise -> Legacy behavior (AIO VPs).
 */
export function determineStrategy(config: InformixConfig): IOStrategy {
  // Rule 1: DIRECT_IO overrides everything
  if (config.directIO) {
    return {
      mode: 'KAIO',
      threadsUsed: config.cpuVps,
      reason: "DIRECT_IO is enabled. All filesystem chunks bypass the OS buffer cache and are handled by KAIO threads (1 per CPU VP).",
      efficiency: 'high'
    };
  }

  // Rule 2: Filesystem Block Size Check (The "Fix")
  // Note: 2048 bytes = 2k
  if (config.filesystemBlockSize > 2048) {
    return {
      mode: 'KAIO',
      threadsUsed: config.cpuVps,
      reason: `Filesystem block size is ${(config.filesystemBlockSize / 1024).toFixed(0)}k (> 2k). The latest update allows KAIO threads to handle these chunks directly.`,
      efficiency: 'high'
    };
  }

  // Rule 3: Fallback / Legacy
  return {
    mode: 'AIO_VP',
    threadsUsed: 0, // AIO VPs are separate entities, not 1:1 with CPU VPs in this context
    reason: "Filesystem block size is ≤ 2k and DIRECT_IO is off. Chunks are handled by AIO VPs, not KAIO threads. This may involve context switching overhead.",
    efficiency: 'low'
  };
}