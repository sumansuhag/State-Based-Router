import { useState } from "react";
import { Layout } from "./components/Layout";
import { Dashboard } from "./pages/Dashboard";
import { Documentation } from "./pages/Documentation";
import { Settings } from "./pages/Settings";
import { InformixConfig } from "./types/informix";

type Page = 'dashboard' | 'docs' | 'settings';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  
  // We lift state up so Settings can reset it if needed
  const [config, setConfig] = useState<InformixConfig>({
    directIO: false,
    filesystemBlockSize: 4096,
    cpuVps: 4,
    chunkCount: 3
  });

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard config={config} onConfigChange={setConfig} />;
      case 'docs':
        return <Documentation />;
      case 'settings':
        return <Settings config={config} onConfigChange={setConfig} />;
      default:
        return <Dashboard config={config} onConfigChange={setConfig} />;
    }
  };

  return (
    <Layout 
      currentPage={currentPage} 
      onPageChange={setCurrentPage}
    >
      {renderPage()}
    </Layout>
  );
}

export default App;