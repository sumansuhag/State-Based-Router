import { ConfigPanel } from "../components/ConfigPanel";
import { ArchitectureView } from "../components/ArchitectureView";
import { AnalysisCard } from "../components/AnalysisCard";
import { InformixConfig } from "../types/informix";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";

interface DashboardProps {
  config: InformixConfig;
  onConfigChange: (config: Partial<InformixConfig>) => void;
}

export function Dashboard({ config, onConfigChange }: DashboardProps) {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="mb-8 border-b border-slate-800 pb-6">
        <h2 className="text-3xl font-bold tracking-tight text-white mb-2">
          I/O Strategy Simulator
        </h2>
        <p className="text-slate-400 max-w-2xl">
          Visualize how DIRECT_IO and filesystem block sizes dictate KAIO thread allocation.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Controls */}
        <div className="lg:col-span-4 space-y-6">
          <ConfigPanel config={config} onChange={onConfigChange} />
          <AnalysisCard config={config} />
        </div>

        {/* Right Column: Visualization */}
        <div className="lg:col-span-8">
          <ArchitectureView config={config} />
        </div>
      </div>
    </div>
  );
}