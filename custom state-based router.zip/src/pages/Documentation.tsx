import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { AlertTriangle, CheckCircle, Info, FileText } from "lucide-react";

export function Documentation() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold tracking-tight text-white mb-2">
          Technical Documentation
        </h2>
        <p className="text-slate-400">
          Understanding KAIO behavior in IBM Informix Dynamic Server (IDS).
        </p>
      </div>

      {/* The Core Logic Card */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <FileText className="w-6 h-6 text-cyan-500" />
            The "Kagel" Logic
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-lg">
            <p className="text-sm text-slate-300 italic mb-4">
              "If DIRECT_IO is set then all chunks built on filesystem files, regardless of page size, are handled by the KAIO threads, one in each CPU VP."
            </p>
            <div className="text-right text-xs text-slate-500 font-mono">
              — Art S. Kagel, President and Principal Consultant<br/>
              ASK Database Management Corp.
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Behavioral Rules</h3>
            
            <div className="flex gap-4">
              <div className="flex-shrink-0 mt-1">
                <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold">1</div>
              </div>
              <div>
                <h4 className="text-white font-medium">DIRECT_IO Override</h4>
                <p className="text-sm text-slate-400 mt-1">
                  When <code className="bg-slate-800 px-1 py-0.5 rounded text-cyan-300">DIRECT_IO</code> is enabled, 
                  the OS buffer cache is bypassed. All chunks are immediately routed to KAIO threads. 
                  This is the highest priority rule.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0 mt-1">
                <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold">2</div>
              </div>
              <div>
                <h4 className="text-white font-medium">Filesystem Block Size Threshold</h4>
                <p className="text-sm text-slate-400 mt-1">
                  Historically, filesystems with blocks ≤ 2k were not handled by KAIO. 
                  The <Badge variant="outline" className="ml-2 border-amber-500/50 text-amber-400">Latest Fix</Badge> 
                  updated this logic. Now, if the filesystem block size is <strong>greater than 2k</strong>, 
                  KAIO threads are used.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0 mt-1">
                <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 font-bold">3</div>
              </div>
              <div>
                <h4 className="text-white font-medium">The Irrelevant Factor</h4>
                <p className="text-sm text-slate-400 mt-1">
                  The <strong>dbspace pagesize</strong> does <span className="text-red-400">not</span> determine KAIO usage. 
                  Only the underlying filesystem block size matters for this specific decision tree.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Comparison Table */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>Scenario Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-slate-500 uppercase bg-slate-950/50">
                <tr>
                  <th className="px-4 py-3 rounded-l-lg">DIRECT_IO</th>
                  <th className="px-4 py-3">FS Block Size</th>
                  <th className="px-4 py-3">Mechanism</th>
                  <th className="px-4 py-3 rounded-r-lg">Performance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                <tr className="hover:bg-slate-800/50">
                  <td className="px-4 py-3"><Badge className="bg-cyan-600">ON</Badge></td>
                  <td className="px-4 py-3 font-mono text-slate-300">Any</td>
                  <td className="px-4 py-3 text-cyan-400 font-medium">KAIO Threads</td>
                  <td className="px-4 py-3"><CheckCircle className="w-4 h-4 text-emerald-500 inline mr-2" />High</td>
                </tr>
                <tr className="hover:bg-slate-800/50">
                  <td className="px-4 py-3"><Badge variant="outline" className="border-slate-600 text-slate-400">OFF</Badge></td>
                  <td className="px-4 py-3 font-mono text-slate-300">> 2k (e.g., 4k)</td>
                  <td className="px-4 py-3 text-cyan-400 font-medium">KAIO Threads</td>
                  <td className="px-4 py-3"><CheckCircle className="w-4 h-4 text-emerald-500 inline mr-2" />High</td>
                </tr>
                <tr className="hover:bg-slate-800/50">
                  <td className="px-4 py-3"><Badge variant="outline" className="border-slate-600 text-slate-400">OFF</Badge></td>
                  <td className="px-4 py-3 font-mono text-slate-300">≤ 2k</td>
                  <td className="px-4 py-3 text-slate-400 font-medium">AIO VPs</td>
                  <td className="px-4 py-3"><AlertTriangle className="w-4 h-4 text-amber-500 inline mr-2" />Lower</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}