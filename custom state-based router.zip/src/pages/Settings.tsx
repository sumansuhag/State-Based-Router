import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { InformixConfig } from "../types/informix";
import { RotateCcw, Download, Save } from "lucide-react";

interface SettingsProps {
  config: InformixConfig;
  onConfigChange: (config: Partial<InformixConfig>) => void;
}

export function Settings({ config, onConfigChange }: SettingsProps) {
  const handleReset = () => {
    onConfigChange({
      directIO: false,
      filesystemBlockSize: 4096,
      cpuVps: 4,
      chunkCount: 3
    });
  };

  const handleExport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(config, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "informix_io_config.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold tracking-tight text-white mb-2">
          Settings
        </h2>
        <p className="text-slate-400">
          Manage application configuration and data.
        </p>
      </div>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>Configuration Management</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Current Config Display */}
          <div className="p-4 bg-slate-950 rounded-lg border border-slate-800">
            <h3 className="text-xs text-slate-500 uppercase tracking-wider mb-3">Current State</h3>
            <pre className="text-xs text-cyan-300 font-mono overflow-x-auto">
              {JSON.stringify(config, null, 2)}
            </pre>
          </div>

          {/* Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button 
              variant="outline" 
              className="border-slate-700 text-slate-300 hover:bg-slate-800"
              onClick={handleReset}
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset to Defaults
            </Button>
            
            <Button 
              className="bg-cyan-600 hover:bg-cyan-500 text-white"
              onClick={handleExport}
            >
              <Download className="w-4 h-4 mr-2" />
              Export Config (JSON)
            </Button>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-emerald-500/10 rounded-lg">
                <Save className="w-4 h-4 text-emerald-500" />
              </div>
              <div>
                <h4 className="text-sm font-medium text-white">Auto-Save</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Configuration changes are automatically persisted in the browser's session state for this demo.
                </p>
              </div>
            </div>
          </div>

        </CardContent>
      </Card>
    </div>
  );
}